
<?php $__env->startSection('content'); ?>

    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mahasiswa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <form action="/mahasiswa/edit" method="post">
        <?php echo e(csrf_field()); ?>

        <div class="row">
            <div class="col-md-6">
              <div class="card card-primary">
                <div class="card-header">
                  <h3 class="card-title">Edit</h3>
        
                  <div class="card-tools">
                    <button type="button" class="btn btn-tool" data-card-widget="collapse" data-toggle="tooltip" title="Collapse">
                      <i class="fas fa-minus"></i></button>
                  </div>
                </div>
                <div class="card-body">
                  <div class="form-group">
                    <label for="inputName">NIM</label>
                    <input type="text" name="nim" class="form-control" required="required" value="<?php echo e($mahasiswa->nim); ?>" placeholder="NIM">
                  <div class="form-group">
                    <label for="inputName">NAMA</label>
                    <input type="text" name="nama" class="form-control" required="required" value="<?php echo e($mahasiswa->nama); ?>" placeholder="Nama Lengkap">
                  <div class="form-group">
                    <label for="inputName">ALAMAT</label>
                    <input type="text" name="alamat" class="form-control" required="required" value="<?php echo e($mahasiswa->alamat); ?>" placeholder="Alamat">
                  <div class="form-group">
                    <label for="inputName">HP</label>
                    <input type="text" name="hp" class="form-control" required="required" value="<?php echo e($mahasiswa->hp); ?>" placeholder="hp">
                  </div>
                </div>
            </div>
          </div>
          <div class="row">
            <div class="col-12">
              <a href="/mahasiswa" class="btn btn-secondary">Cancel</a>
              <input type="submit" value="Save Changes" class="btn btn-success float-right">
            </div>
          </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\DEVELOPER\FRAMEWORK\LARAVEL\LARAVEL_V10\MODUL\web_mahes\resources\views/ubah.blade.php ENDPATH**/ ?>