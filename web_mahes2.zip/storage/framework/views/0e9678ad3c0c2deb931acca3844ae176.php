
<?php $__env->startSection('content'); ?>

    <h3>Halaman Tambah Data Mahasiswa</h3>
    <a href="/mahasiswa">Kembali</a>
    <br>

    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mahasiswa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <form action="/mahasiswa/edit" method="post">
        <?php echo e(csrf_field()); ?>

        NIM <input type="text" name="nim" required="required" value="<?php echo e($mahasiswa->nim); ?>" placeholder="NIM"><br>
        Nama <input type="text" name="nama" required="required" value="<?php echo e($mahasiswa->nama); ?>" placeholder="Nama Lengkap"><br>
        Alamat <input type="text" name="alamat" required="required" value="<?php echo e($mahasiswa->alamat); ?>" placeholder="Alamat"><br>
        Hp <input type="text" name="hp" required="required" value="<?php echo e($mahasiswa->hp); ?>" placeholder="hp"><br>
        <input type="submit" value="Simpan Data">
    </form>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</body>
</html> 

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\DEVELOPER\FRAMEWORK\LARAVEL\LARAVEL_V10\MODUL\web_mahes\resources\views/ubah1.blade.php ENDPATH**/ ?>